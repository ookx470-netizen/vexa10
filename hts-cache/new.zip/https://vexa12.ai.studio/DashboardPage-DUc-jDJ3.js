<!doctype html>
<html lang="ar" dir="rtl" class="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>منصة فيكسا للاستثمار | VEXA Investment Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script type="module" crossorigin src="/assets/index-Deee81kR.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-BpBd4gZv.css">
  </head>
  <body class="bg-[#0A0D14] text-slate-100 font-['Cairo',sans-serif] antialiased selection:bg-amber-500/30 selection:text-amber-200 min-h-screen">
    <div id="root"></div>
  </body>
</html>

